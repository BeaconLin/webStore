### 问题是什么

问题的具体描述，尽量详细

### 环境

- 系统: MAC 10.14.x
- 浏览器：Chrome 7.4.x
- 版本：2.0.0
- 用到的插件: template, rollup-plugin-templatejs
- 其他信息

### 在线例子

如果有请提供在线例子

### 其他

其他信息