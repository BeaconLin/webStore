import { PrecompileOption } from '@templatejs/precompiler';
export interface Options extends PrecompileOption {
    global?: string;
}
