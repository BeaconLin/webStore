# 本地webpack 2例子

安装本地依赖

```bash
$ npm install
```

运行webpack打包

```bash
$ npm run build
```
