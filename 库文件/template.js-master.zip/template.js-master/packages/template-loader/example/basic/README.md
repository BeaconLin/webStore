# 全局webpack例子

首先全局安装webpack

```bash
$ npm install -g wepback
```

运行webpack打包

```bash
$ wepback
```
