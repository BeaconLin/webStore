# 本地webpack 1例子

安装本地依赖

```bash
$ npm install
```

运行webpack打包

```bash
$ npm run build
```
