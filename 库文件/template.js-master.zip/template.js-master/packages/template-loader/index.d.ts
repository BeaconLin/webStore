import { PrecompileOption } from '@templatejs/precompiler';
export interface Options extends PrecompileOption {
}
export default function (tpl: string): string;
