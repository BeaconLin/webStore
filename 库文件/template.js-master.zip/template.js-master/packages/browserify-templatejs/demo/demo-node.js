var base = require('../dist/index.js');
console.log(base.name);
