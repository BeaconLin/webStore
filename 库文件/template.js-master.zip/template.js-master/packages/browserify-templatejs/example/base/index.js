const tpl = require("./demo.tmpl");

console.log('run', tpl({}));
