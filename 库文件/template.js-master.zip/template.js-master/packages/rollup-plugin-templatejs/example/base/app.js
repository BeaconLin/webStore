import tpl from './test.tmpl';

document.querySelector('#container').innerHTML = tpl({ name: 'yanhaijing' });