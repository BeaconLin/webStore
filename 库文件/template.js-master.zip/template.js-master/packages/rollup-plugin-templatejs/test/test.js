var expect = require('expect.js');

// js 测试源文件
var base = require('../src/index.ts');

describe('单元测试', function() {
    this.timeout(1000);
});
