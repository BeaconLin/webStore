# fis3 demo

安装fis

```bash
$ npm install -g fis3
```

安装fis插件

```bash
$ npm install -g fis-parser-template
```

本地运行

```bash
$ fis3 server start
$ fis3 release
```

打开如下url，http://127.0.0.1:8080/basic.html
