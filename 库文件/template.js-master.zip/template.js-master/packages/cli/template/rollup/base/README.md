# 本地rollup例子

安装本地依赖

```bash
$ npm install
```

运行rollup打包

```bash
$ npm run build
```
