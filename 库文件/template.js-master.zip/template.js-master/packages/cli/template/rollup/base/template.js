import template from "@templatejs/runtime";
window.template = template;

export { template };
